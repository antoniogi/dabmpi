/***************************************************************************
*   Copyright (C) 2008 by Antonio Gómez                                   *
*   antonio.gomez@ciemat.es                                               *
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef TIPOS_H
#define TIPOS_H

/**
    @author Antonio Gómez <antonio.gomez@ciemat.es>
    @file tipos.h
    @version 0.01
    @date 30-01-2008
 */

#define PI 3.14159265
#define MAX_DOUBLE 1000000000
#define MIN_DOUBLE -1000000000
#define SIZE_CHROMOSOME 23
#define SIZE_POBLACION 1000

//////////////////////////////////////////////////////////////////////////////
//              Estructuras para el fichero flx
//////////////////////////////////////////////////////////////////////////////

//Estructura para almacenar la cabecera del fichero .flx
struct strCabecera
{
    char*   nombreFichero;
    char*   betat;
    int     nhl;
    char*   chl;
    char*   rot;
    char*   rin;
    char*   rmd;
    int     nrho;
    int     modnum;
};

//Estructura que almacena el contenido de cada una de las líneas de las iteraciones contenidas en el fichero.
struct strLinea
{
    int     m;
    int     n;
    //char    rmn [20];
    //char    zmn [20];
    double rmndouble;
    double zmndouble;
    char   fin [15];
};

//Estructura que almacena el resumen de una iteración.
struct strResIteracion
{
    char   rho  [20];
    char   q    [20];
    char   vp   [20];
    char   b0   [20];
    char   et   [20];
    char   eh   [20];
};

//Estructura que representa una iteración completa.
struct strIteracion
{
    int             iter;
    strLinea        lineas [400];
    strResIteracion resumen;
    int             numLineas;
};

//Estructura que representa al fichero flx.
struct strficheroFLX
{
    strCabecera     cabecera;
    strIteracion    iteraciones [200];
    int             numIteraciones;
};

struct strvector3
{
	double a;
	double b;
	double c;
};
//Estructura para almacenar los resultados de calcular la función de transporte sobre la información del fichero flx.
struct strvaloresTransporte
{
    double *Zvalue;//[200][360][360];
    double *Rvalue;//[200][360][360];
    double *Xvalue;//[200][360][360];
    strvector3 *gradienteB;//[200][360][360];
    strvector3 *Bx;//[200][360][360];
    int numIter;
};

//////////////////////////////////////////////////////////////////////////////
//              Estructuras para el fichero de input
//////////////////////////////////////////////////////////////////////////////
struct strdatos {
    char ficheroGrid [20];
    bool lfreeb;
    bool loptim;
    double delt;
    double tcon0;
    int nfp;
    int ncurr;
    int mpol;
    int ntor;
    int nzeta;
    int ns_array[4];             // ¿Siempre es un array de cuatro valores?
    int niter;
    int nstep;
    int nvacskip;
    double gamma;
    double ftol_array [4];       // ¿Siempre es un array de cuatro valores?
    double phiedge;
    double extcur_array [5];     // ¿Siempre es un array de cinco valores?
    double curtor;
    double spres_ped;
    double am_array [11];         // ¿Siempre es un array de once valores? ¿Siempre va en dos líneas?
    double ai_array [11];         // ¿Siempre es un array de once valores? ¿Siempre va en dos líneas?
    double ac_array [11];         // ¿Siempre es un array de once valores? ¿Siempre va en dos líneas?
    double raxis_array [2];      // ¿Siempre es un array de dos valores?
    double zaxis_array [2];      // ¿Siempre es un array de dos valores?
};

struct strcoordenada {
    int val1, val2;
    double value;
};

struct strlinea {
    strcoordenada rbc, zbs;
    bool empty;
};

struct strsigma_jstar {
    int coordenada1,coordenada2;
    double values [31];       // ¿Siempre 31 valores? ¿Siempre iguales?
};

struct stroptimum
{
    double epsfcn;
    int niter_opt;
    bool lreset_opt;
    bool lprof_opt;
    bool lbmn;
    char * lfix_ntor;       // Aquí pone 61*F, ¿significa eso tener 61 F?
    bool lsurf_mask_array [31];       // ¿Cuántos valores?
    double target_aspectratio;
    double target_beta;
    double target_maxcurrent;
    double target_rmax;
    double target_rmin;
    double target_iota [11];  // ¿Siempre once valores?
    double target_well [11];  // ¿Siempre once valores?
    double sigma_aspect;
    double sigma_curv;
    double sigma_beta;
    double sigma_kink;
    double sigma_maxcurrent;
    double sigma_rmax;
    double sigma_rmin;
    double sigma_iota [31];   // ¿Siempre 31 valores?
    double sigma_vp [31];     // ¿Siempre 31 valores? ¿Siempre iguales?
    double sigma_bmin [31];   // ¿Siempre 31 valores? ¿Siempre iguales?
    double sigma_bmax [31];   // ¿Siempre 31 valores? ¿Siempre iguales?
    double sigma_ripple [31];   // ¿Siempre 31 valores? ¿Siempre iguales?
    strsigma_jstar sigma_jstar[4];   // ¿Siempre 4?
    double sigma_balloon [31];    // ¿Siempre 31 valores? ¿Siempre iguales?
    double sigma_pgrad [31];    // ¿Siempre 31 valores? ¿Siempre iguales?
    double sigma_pedge;
    bool lballon_test;
    double bal_zeta0;
    double bal_theta0;
    double bal_xmax;
    double bal_np0;
    double bal_kth;
    double bal_x0;
};

struct strbootin
{
    double nrh0;
    double mbuse;
    double nbuse;
    double zeff1;
    double damp;
    double isymm0;
    char* ate [12]; // ¿Siempre 12 valores?
    char* ati [12]; // ¿Siempre 12 valores?
};

struct strficheroInput
{
    strdatos datos;
    strlinea lineas [300];
    int numLineas;
    stroptimum optimum;
    strbootin bootin;
};

//////////////////////////////////////////////////////////////////////////////
//              Estructuras para el algoritmo genético
//////////////////////////////////////////////////////////////////////////////

struct strchromosomes
{
/*
    int nfp;
    int ncurr;
    int mpol;
    int ntor;
    int nzeta;
    int niter;
    int nstep;
    int nvacskip;

    double delt;
    double tcon0;

    double sigma_pedge;
    double bal_zeta0;
    double bal_theta0;
    double bal_xmax;
    double bal_np0;
    double bal_kth;
    double bal_x0;

    double nrh0;
    double mbuse;
    double nbuse;
    double zeff1;
    double damp;
    double isymm0;
*/
  double chromosome [SIZE_CHROMOSOME];
};

struct strindividuo
{
    strchromosomes cromosoma;

    double valor;

    bool enfrentado;

    bool calculado;
};

struct strpoblacion
{
    strindividuo individuos[SIZE_POBLACION];
    int numIndividuos;
};

#endif
