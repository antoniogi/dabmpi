/***************************************************************************
 *   Copyright (C) 2008 by Antonio Gómez                                   *
 *   antonio.gomez@ciemat.es                                               *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "transport.h"

transport::transport()
{
   valTransport.Zvalue=(double *) malloc (200*360*360*sizeof (double));
   valTransport.Rvalue=(double *) malloc (200*360*360*sizeof (double));
   valTransport.Xvalue=(double *) malloc (200*360*360*sizeof (double));
   valTransport.gradienteB=(strvector3 *) malloc (200*360*360*sizeof (strvector3));
   valTransport.Bx=(strvector3 *) malloc (200*360*360*sizeof (strvector3));
}

transport::~transport()
{
    free (valTransport.Zvalue);
    free (valTransport.Rvalue);
    free (valTransport.Xvalue);
    free (valTransport.gradienteB);
    free (valTransport.Bx);
}

void transport::setFicheroFLX (strficheroFLX fichero)
{
    fich = fichero;
}

strvaloresTransporte transport::getValoresTransporte ()
{
    return valTransport;
}


double transport::calcularFuncionZ (int iter, int ro, int fi)
{
    double result = 0.0;
    double multiplicador;
    int nXangle1;
    double divisor = PI/180;

    for (int i = 0; i<fich.iteraciones[iter].numLineas; i++)
    {
        multiplicador = fich.iteraciones[iter].lineas[i].zmndouble;
        result+=multiplicador*sin((fich.iteraciones[iter].lineas[i].n*ro-fich.iteraciones[iter].lineas[i].m*fi)*divisor);
    }
    return result;
}

double transport::calcularFuncionR (int iter, int ro, int fi)
{
    double result = 0.0;
    double multiplicador;
    int nXangle1;
    double divisor = PI/180;

    for (int i = 0; i<fich.iteraciones[iter].numLineas; i++)
    {
        multiplicador = fich.iteraciones[iter].lineas[i].rmndouble;
        result+=multiplicador*cos((fich.iteraciones[iter].lineas[i].n*ro-fich.iteraciones[iter].lineas[i].m*fi)*divisor);
    }
    return result;
}

strvector3 transport::calcularGradiente (int p, int ro, int fi)
{
    strvector3 temp;
    double divisor = PI/180;
    double sumaParcialP, sumaParcialRo, sumaParcialFi;
    double multiplicador;
    double result;
    int posVector;

    sumaParcialP = 0.0;
    sumaParcialRo = 0.0;
    sumaParcialFi = 0.0;
    temp.a=0.0;
    temp.b=0.0;
    temp.c=0.0;

    posVector = (fi)+(ro)*360+(p)*360*360;

    for (int i = 0; i<fich.iteraciones[p].numLineas; i++)
    {
        //multiplicador = valTransport.Zvalue[p][ro][fi];
        multiplicador = valTransport.Zvalue[posVector];
        result+=fich.iteraciones[p].lineas[i].m*multiplicador*cos((fich.iteraciones[p].lineas[i].m*ro-fich.iteraciones[p].lineas[i].n*fi)*divisor);
        //multiplicador = valTransport.Rvalue[p][ro][fi];
        multiplicador = valTransport.Rvalue[posVector];
        result-=fich.iteraciones[p].lineas[i].m*multiplicador*sin((fich.iteraciones[p].lineas[i].m*ro-fich.iteraciones[p].lineas[i].n*fi)*divisor);
        temp.b += result;

        result = 0.0;
        //multiplicador = valTransport.Rvalue[p][ro][fi];
        multiplicador = valTransport.Rvalue[posVector];
        result+=fich.iteraciones[p].lineas[i].n*multiplicador*sin((fich.iteraciones[p].lineas[i].m*ro-fich.iteraciones[p].lineas[i].n*fi)*divisor);
        //multiplicador = valTransport.Zvalue[p][ro][fi];
        multiplicador = valTransport.Zvalue[posVector];
        result-=fich.iteraciones[p].lineas[i].n*multiplicador*cos((fich.iteraciones[p].lineas[i].m*ro-fich.iteraciones[p].lineas[i].n*fi)*divisor);
        temp.c += result;
    }
    return temp;
}

double transport::calcularFuncionB(int iter, int ro, int fi)
{
    double result = 0.0;
    double multiplicador;
    int nXangle1;
    double divisor = PI/180;

    int posVector = (fi)+(ro)*360+(iter)*360*360;
    for (int i = 0; i<fich.iteraciones[iter].numLineas; i++)
    {
        //multiplicador = valTransport.Xvalue[iter][ro][fi];
        multiplicador = valTransport.Xvalue[posVector];
        result+=multiplicador*cos((fich.iteraciones[iter].lineas[i].n*ro-fich.iteraciones[iter].lineas[i].m*fi)*divisor);
    }
    return result;
}

void transport::calcularValoresTransporte ()
{
    strvector3 temp;
    int posVector;
    for (int i=0; i<=fich.numIteraciones; i++)
    {
        for (int ro= 0; ro<360; ro++)
        {
            for (int fi=0; fi<360; fi++)
            {
                temp.a=0.0;
                temp.b=0.0;
                temp.c=0.0;
                
                posVector = (fi)+(ro)*360+(i)*360*360;
                /*valTransport.Zvalue[i][ro][fi] = calcularFuncionZ(i, ro, fi);
                valTransport.Rvalue[i][ro][fi] = calcularFuncionR(i, ro, fi);
                valTransport.Xvalue[i][ro][fi] = valTransport.Zvalue[i][ro][fi]+valTransport.Rvalue[i][ro][fi]; */
                valTransport.Zvalue[posVector] = calcularFuncionZ(i, ro, fi);
                valTransport.Rvalue[posVector] = calcularFuncionR(i, ro, fi);
                valTransport.Xvalue[posVector] = valTransport.Zvalue[posVector]+valTransport.Rvalue[posVector];
                //temp.a = valTransport.Xvalue[i][ro][fi];
                temp.a = valTransport.Xvalue[posVector];
                temp.b=ro;
                temp.c=fi;
                /*valTransport.gradienteB[i][ro][fi] = calcularGradiente(i, ro, fi);
                valTransport.Bx[i][ro][fi] = temp; */
                valTransport.gradienteB[posVector] = calcularGradiente(i, ro, fi);
                valTransport.Bx[posVector] = temp;



                //valTransport.Bx[i]+=calcularFuncionB (i,ro,fi);//valTransport.Xvalue[i][ro][fi]*cos((ro*n-fi*m)/(PI/180));//Revisar esta función
            }
        }
    }
    valTransport.numIter=fich.numIteraciones;
}

double transport::calcularFuncionObjetivo()
{

    double output=0.0;
    double temporal;
    strvector3 temp;
    double potencia;

    for (int i = 0; i<=fich.numIteraciones; i++)
    {
        temporal = 0;
        for (int ro=0; ro<360; ro++)
        {
            for (int fi=0;fi<360;fi++)
            {
             //   potencia = pow(valTransport.Xvalue[i][ro][fi],3);
                potencia = pow(valTransport.Xvalue[(fi)+(ro)*360+(i)*360*360],3);
                if (potencia!=0)
                {
                    //temp = multiplicarVectores(valTransport.Bx[i][ro][fi],valTransport.gradienteB[i][ro][fi]);
                    temp = multiplicarVectores(valTransport.Bx[(fi)+(ro)*360+(i)*360*360],valTransport.gradienteB[(fi)+(ro)*360+(i)*360*360]);
                    temp.a = temp.a/potencia;
                    temp.b = temp.b/potencia;
                    temp.c = temp.c/potencia;
                    output+=modulo (temp);
                }
            }
        }
//        output += (valTransport.Bx[i])/pow(valTransport.Bx[i],3);
    }
    return output;

}

double transport::modulo (strvector3 vector)
{
    double temp;
    temp = sqrt (pow(vector.a,2)+pow(vector.b,2)+pow(vector.c,2));
    return temp;
}

strvector3 transport::multiplicarVectores (strvector3 vector1, strvector3 vector2)
{
    strvector3 temp;
    temp.a = vector1.b*vector2.c-vector1.c*vector2.b;
    temp.b = vector1.a*vector2.c-vector1.c*vector2.a;
    temp.c = vector1.a*vector2.b-vector1.b*vector2.a;
    return temp;
}
