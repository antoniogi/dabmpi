/***************************************************************************
 *   Copyright (C) 2008 by Antonio Gómez                                   *
 *   antonio.gomez@ciemat.es                                               *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "readerinput.h"

readerInput::readerInput()
    : fichero()
{
}

readerInput::~readerInput()
{
}

strdatos readerInput::leerDatos()
{
    char * text;
    char * eltosLinea [4];
    char * subEltosLinea [4];
    char * tok;
    char key [] = "FT";
    int i;
    strdatos datos;

    leerSiguienteLinea();   //&INDATA
    text = leerValor();
    strcpy (datos.ficheroGrid, text);

    eltosLinea[1] = leerValor();

    eltosLinea[1]= strpbrk (eltosLinea[1], key);
    if (!strcmp (eltosLinea[1], "T"))
    {
        datos.lfreeb = true;
    }
    else
    {
        datos.lfreeb = false;
    }

    eltosLinea[1] = leerValor();
    eltosLinea[1]= strpbrk (eltosLinea[1], key);
    if (!strcmp (eltosLinea[1], "T"))
    {
        datos.loptim = true;
    }
    else
    {
        datos.loptim = false;
    }

    datos.delt = atof (leerValor());

    datos.tcon0 = atof (leerValor());

    datos.nfp = atoi (leerValor());

    datos.ncurr = atoi (leerValor());

    text = leerSiguienteLinea();
    i=0;
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }

    i=0;
    tok = strtok (eltosLinea[1], "NTOR");
    while (tok != NULL)
    {
        subEltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }

    datos.mpol = atoi (subEltosLinea[0]);
    datos.ntor = atoi (eltosLinea[2]);

    datos.nzeta = atoi (leerValor());

    text = leerSiguienteLinea();
    leerArrayInteger (text);
    for (i=0; i<4; i++)
    {
        datos.ns_array[i] = array_int [i];
    }

    datos.niter =       atoi (leerValor());
    datos.nstep =       atoi (leerValor());
    datos.nvacskip =    atoi (leerValor());
    datos.gamma =       atof (leerValor());

    text = leerSiguienteLinea();
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());

    leerArrayDouble (text);

    for (i = 0; i<4; i++)
    {
        datos.ftol_array [i] = array_double [i];
    }

    datos.phiedge = atof (leerValor());

    text = leerSiguienteLinea();
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());	
    leerArrayDouble (text);
    for (i = 0; i<5; i++)
    {
        datos.extcur_array [i] = array_double [i];
    }

    datos.curtor = atof (leerValor());
    datos.spres_ped = atof (leerValor());

    text = leerSiguienteLinea();
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());	
    leerArrayDouble (text);
    for (i = 0; i<11; i++)
    {
        datos.am_array [i] = array_double [i];
    }

    text = leerSiguienteLinea();
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    leerArrayDouble (text);
    for (i = 0; i<11; i++)
    {
        datos.ai_array [i] = array_double [i];
    }

    text = leerSiguienteLinea();
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());	
    leerArrayDouble (text);
    for (i = 0; i<11; i++)
    {
        datos.ac_array [i] = array_double [i];
    }

    text = leerSiguienteLinea();
    i=0;
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    i=0;
    tok = strtok (eltosLinea[1], ",");
    while (tok != NULL)
    {
        subEltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    datos.raxis_array [0] = atof (subEltosLinea[0]);
    datos.raxis_array [1] = atof (subEltosLinea[1]);

    text = leerSiguienteLinea();
    i=0;
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    i=0;
    tok = strtok (eltosLinea[1], ",");
    while (tok != NULL)
    {
        subEltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    datos.zaxis_array [0] = atof (subEltosLinea[0]);
    datos.zaxis_array [1] = atof (subEltosLinea[1]);

    return datos;
}

void readerInput::leerArrayDouble (char* text)
{
    char * tok;
    char * eltosLinea [2];
    int i;

    i=0;
    tok = strtok (text, "=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }

    i=0;
    tok = strtok (eltosLinea[1], " ");
    while (tok!=NULL)
    {
        array_double [i] = atof (tok);
        i++;
        tok = strtok (NULL, " ");
    }
}

void readerInput::leerArrayBool (char* text)
{
    char * tok;
    char * eltosLinea [2];
    char * key;
//    char * key = "FT";
    int i;

    strcpy (key, "FT");
    i=0;
    tok = strtok (text, "=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }

    i=0;
    tok = strtok (eltosLinea[1], " ");
    while (tok!=NULL)
    {
        if (!strcmp (strpbrk (tok, key), "T"))
        {
            array_bool [i] = true;
        }
        else
        {
            array_bool [i] = false;
        }
        i++;
        tok = strtok (NULL, " ");
    }
}

void readerInput::leerArrayDouble (char* text, bool leerIgual)
{
    char * tok;
    int i;

    i=0;
    tok = strtok (text, " ");
    while (tok!=NULL)
    {
        array_double [i] = atof (tok);
        i++;
        tok = strtok (NULL, " ");
    }
}

void readerInput::leerArrayInteger (char* text)
{
    char * tok;
    char * eltosLinea [2];
    int i;

    i=0;
    tok = strtok (text, "=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }

    i=0;
    tok = strtok (eltosLinea[1], " ");
    while (tok!=NULL)
    {
        array_int [i] = atoi (tok);
        i++;
        tok = strtok (NULL, " ");
    }
}

strsigma_jstar readerInput::leerArrayJStar (char * text)
{
    char * tok;
    strsigma_jstar jstar;
    char * eltosLinea [2];
    char * subEltosLinea [2];
    char * subSubEltosLinea [2];
    int i;

    i=0;
    tok = strtok (text, "=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }

    i=0;
    tok = strtok (eltosLinea[0], "(");
    while (tok!=NULL)
    {
        subEltosLinea[i] = tok;
        i++;
        tok = strtok (NULL, "(");
    }

    i=0;
    tok = strtok (subEltosLinea[1], ",");
    while (tok!=NULL)
    {
        subSubEltosLinea[i] = tok;
        i++;
        tok = strtok (NULL, ",");
    }

    jstar.coordenada1 = atoi (subSubEltosLinea [0]);
    tok = strtok (subSubEltosLinea [1], ")");
    jstar.coordenada2 = atoi (tok);

    i=0;
    tok = strtok (eltosLinea[1], " ");
    while (tok!=NULL)
    {
        if (isascii (tok[0]))
        {
            if (isdigit (tok[0]))
            {
                if (strcmp (tok, "Q"))
                {
                    jstar.values[i] = atof (tok);
                    i++;
                }
            }
        }
        tok = strtok (NULL, " ");
    }
    return jstar;
}

char* readerInput::leerValor()
{
    char* text;
    int i;
    char * tok;
    char * eltosLinea [2];

    text = leerSiguienteLinea();
    i=0;
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    return (eltosLinea[1]);
}

char* readerInput::leerValor(int size)
{
    char* text;
    int i;
    char * tok;
    char * eltosLinea [2];

    text = leerSiguienteLinea(size);
    i=0;
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    return (eltosLinea[1]);
}

char* readerInput::leerValor(char * text)
{
    int i;
    char * tok;
    char * eltosLinea [2];

    i=0;
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    return (eltosLinea[1]);
}

stroptimum readerInput::leerOptimum ()
{
    char * text;
    stroptimum optimum;
    int i;
    char key [] = "FT";

    text = leerSiguienteLinea();
    text = leerSiguienteLinea();

    optimum.epsfcn = atof (leerValor());
    optimum.niter_opt = atoi (leerValor());

    text = leerValor();
    if (!strcmp (strpbrk (text, key), "T"))
    {
        optimum.lreset_opt = true;
    }
    else
    {
        optimum.lreset_opt = false;
    }

    text = leerValor();
    if (!strcmp (strpbrk (text, key), "T"))
    {
        optimum.lprof_opt = true;
    }
    else
    {
        optimum.lprof_opt = false;
    }

    text = leerValor();
    if (!strcmp (strpbrk (text, key), "T"))
    {
        optimum.lbmn = true;
    }
    else
    {
        optimum.lbmn = false;
    }

    optimum.lfix_ntor = leerValor();
    text = leerSiguienteLinea();
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    leerArrayBool (text);
    for (i=0; i<31;i++)
    {
        optimum.lsurf_mask_array[i] = array_bool[i];
    }

    optimum.target_aspectratio =    atof (leerValor());
    optimum.target_beta =           atof (leerValor());
    optimum.target_maxcurrent =     atof (leerValor());
    optimum.target_rmax =           atof (leerValor());
    optimum.target_rmin =           atof (leerValor());

    text = leerSiguienteLinea();
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    leerArrayDouble (text);
    for (i = 0; i<11; i++)
    {
        optimum.target_iota [i] = array_double [i];
    }

    text = leerSiguienteLinea();
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    leerArrayDouble (text);
    for (i = 0; i<11; i++)
    {
        optimum.target_well [i] = array_double [i];
    }

    optimum.sigma_aspect =      atof (leerValor());
    optimum.sigma_curv =        atof (leerValor());
    optimum.sigma_beta =        atof (leerValor());
    optimum.sigma_kink =        atof (leerValor());
    optimum.sigma_maxcurrent =  atof (leerValor());
    optimum.sigma_rmax =        atof (leerValor());
    optimum.sigma_rmin =        atof (leerValor());

    text = leerSiguienteLinea();
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    strcat (text, " ");
    strcat (text, leerSiguienteLinea());
    leerArrayDouble (text);
    for (i = 0; i<31; i++)
    {
        optimum.sigma_iota [i] = array_double [i];
    }

    text = leerSiguienteLinea();
    for ( i = 0 ; i<6; i++)
    {
        strcat (text, " ");
        strcat (text, leerSiguienteLinea());
    }

    leerArrayDouble (text);
    for (i = 0; i<31; i++)
    {
        optimum.sigma_vp [i] = array_double [i];
    }

    text = leerSiguienteLinea();
    for ( i = 0 ; i<6; i++)
    {
        strcat (text, " ");
        strcat (text, leerSiguienteLinea());
    }

    leerArrayDouble (text);
    for (i = 0; i<31; i++)
    {
        optimum.sigma_bmin [i] = array_double [i];
    }

    text = leerSiguienteLinea();
    for ( i = 0 ; i<6; i++)
    {
        strcat (text, " ");
        strcat (text, leerSiguienteLinea());
    }

    leerArrayDouble (text);
    for (i = 0; i<31; i++)
    {
        optimum.sigma_bmax [i] = array_double [i];
    }

    text = leerSiguienteLinea();
    for ( i = 0 ; i<6; i++)
    {
        strcat (text, " ");
        strcat (text, leerSiguienteLinea());
    }

    leerArrayDouble (text);
    for (i = 0; i<31; i++)
    {
        optimum.sigma_ripple [i] = array_double [i];
    }

    text = leerSiguienteLinea();
    for ( i = 0 ; i<7; i++)
    {
        strcat (text, " ");
        strcat (text, leerSiguienteLinea());
    }

    optimum.sigma_jstar [0] = leerArrayJStar (text);

    text = leerSiguienteLinea();
    for ( i = 0 ; i<7; i++)
    {
        strcat (text, " ");
        strcat (text, leerSiguienteLinea());
    }

    optimum.sigma_jstar [1] = leerArrayJStar (text);

    text = leerSiguienteLinea();
    for ( i = 0 ; i<7; i++)
    {
        strcat (text, " ");
        strcat (text, leerSiguienteLinea());
    }

    optimum.sigma_jstar [2] = leerArrayJStar (text);

    text = leerSiguienteLinea();
    for ( i = 0 ; i<7; i++)
    {
        strcat (text, " ");
        strcat (text, leerSiguienteLinea());
    }

    optimum.sigma_jstar [3] = leerArrayJStar (text);

    text = leerSiguienteLinea();
    for ( i = 0 ; i<7; i++)
    {
        strcat (text, " ");
        strcat (text, leerSiguienteLinea());
    }

    leerArrayDouble (text);
    for (i = 0; i<31; i++)
    {
        optimum.sigma_balloon [i] = array_double [i];
    }

    text = leerSiguienteLinea();
    for ( i = 0 ; i<7; i++)
    {
        strcat (text, " ");
        strcat (text, leerSiguienteLinea());
    }

    leerArrayDouble (text);
    for (i = 0; i<31; i++)
    {
        optimum.sigma_pgrad [i] = array_double [i];
    }

    optimum.sigma_pedge = atof (leerValor());
    text= strpbrk (leerValor(), key);
    if (!strcmp (text, "T"))
    {
        optimum.lballon_test = true;
    }
    else
    {
        optimum.lballon_test = false;
    }

    optimum.bal_zeta0 =     atof (leerValor());
    optimum.bal_theta0 =    atof (leerValor());
    optimum.bal_xmax =      atof (leerValor());
    optimum.bal_np0 =       atof (leerValor());
    optimum.bal_kth =       atof (leerValor(16));
    optimum.bal_x0 =        atof (leerValor());

    return optimum;
}

strbootin readerInput::leerBootin()
{
    char * texto;
    char * tok;
    int i;
    char * eltosLinea [8];
    strbootin bootin;

    i=0;
    texto = leerSiguienteLinea ();
    tok = strtok (texto,",");
    while (tok!=NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,",");
    }

    bootin.nrh0     = atoi(leerValor (eltosLinea [0]));
    bootin.mbuse    = atoi(leerValor (eltosLinea [1]));
    bootin.nbuse    = atoi(leerValor (eltosLinea [2]));
    bootin.zeff1    = atof(leerValor (eltosLinea [3]));

    i=0;
    texto = leerSiguienteLinea ();
    tok = strtok (texto,",");
    while (tok!=NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,",");
    }
    bootin.damp = atof (leerValor (eltosLinea[0]));
    bootin.isymm0 = atoi (leerValor(eltosLinea[1]));

    bootin.ate [0] = leerValor (eltosLinea[2]);
    bootin.ate [1] = eltosLinea[3];
    bootin.ate [2] = eltosLinea[4];
    bootin.ate [3] = eltosLinea[5];
    bootin.ate [4] = eltosLinea[6];

    i=0;
    texto = leerSiguienteLinea ();
    tok = strtok (texto,",");
    while (tok!=NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,",");
    }

    bootin.ati [0] = leerValor (eltosLinea[0]);
    bootin.ati [1] = eltosLinea[1];
    bootin.ati [2] = eltosLinea[2];
    bootin.ati [3] = eltosLinea[3];
    bootin.ati [4] = eltosLinea[4];

    return bootin;
}

strlinea readerInput::leerLinea ()
{
    char * texto;
    strlinea linea;
    char * eltosLinea [3];
    char * subEltosLinea [4];
    char * subSubEltosLinea [4];
    char * subSubSubEltosLinea [4];
    char * subSubSubSubEltosLinea [4];
    char * tok;
    int i;

    linea.empty = true;
    texto = leerSiguienteLinea ();
    if (strlen (texto)<10)
    {
        return linea;
    }
    else
    {
        linea.empty=false;
    }

    i=0;
    tok = strtok (texto,"=");
    while (tok!=NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }

    i=0;
    tok = strtok (eltosLinea[0],"(");
    while (tok!=NULL)
    {
        subEltosLinea[i] = tok;
        i++;
        tok = strtok (NULL, "(");
    }
    i=0;
    tok = strtok (subEltosLinea[1],",");
    while (tok!=NULL)
    {
        subSubEltosLinea[i] = tok;
        i++;
        tok = strtok (NULL, ",");
    }
    linea.rbc.val1 = atoi (subSubEltosLinea[0]);
    i=0;
    tok = strtok (subSubEltosLinea[1],")");
    while (tok!=NULL)
    {
        subSubSubEltosLinea[i] = tok;
        i++;
        tok = strtok (NULL, ")");
    }
    linea.rbc.val2 = atoi (subSubSubEltosLinea[0]);

    //Obtención del valor de RBC
    i=0;
    tok = strtok (eltosLinea[1],"ZBS");
    while (tok!=NULL)
    {
        subEltosLinea[i] = tok;
        i++;
        tok = strtok (NULL, "ZBS");
    }
    linea.rbc.value = atof (subEltosLinea[0]);


    i=0;
    tok = strtok (subEltosLinea[1],"(");
    while (tok!=NULL)
    {
        subSubEltosLinea[i] = tok;
        i++;
        tok = strtok (NULL, "(");
    }
    i=0;
    tok = strtok (subSubEltosLinea[0],",");
    while (tok!=NULL)
    {
        subSubSubEltosLinea[i] = tok;
        i++;
        tok = strtok (NULL, ",");
    }
    linea.zbs.val1 = atoi (subSubSubEltosLinea[0]);
    i=0;
    tok = strtok (subSubSubEltosLinea[1],")");
    while (tok!=NULL)
    {
        subSubSubEltosLinea[i] = tok;
        i++;
        tok = strtok (NULL, ")");
    }
    linea.zbs.val2 = atoi (subSubSubSubEltosLinea[0]);

    //Obtención del valor de ZBS
    linea.zbs.value = atof (eltosLinea[2]);

    return linea;
}

strficheroInput readerInput::leerFichero()
{
    strficheroInput contenidoFichero;
    strlinea linea;
    int i;

    contenidoFichero.datos = leerDatos();
    i = 0;
    do
    {
        linea = leerLinea();
        if (!linea.empty)
        {
            contenidoFichero.lineas[i] = linea;
            i++;
        }
    } while (!linea.empty);
    contenidoFichero.numLineas = i;
    contenidoFichero.optimum = leerOptimum();
    leerSiguienteLinea();
    leerSiguienteLinea();
    contenidoFichero.bootin = leerBootin();
    return contenidoFichero;
}
