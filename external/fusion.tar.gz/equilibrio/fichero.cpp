/***************************************************************************
*   Copyright (C) 2008 by Antonio Gómez                                   *
*   antonio.gomez@ciemat.es                                               *
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
***************************************************************************/
#include "fichero.h"

fichero::fichero()
{
}

fichero::~fichero()
{
}

void fichero::abrirFichero (char * nombre)
{
    fi.open (nombre, std::ios::in);
}

void fichero::abrirFicheroEscritura (char * nombre)
{
    pFile = fopen (nombre,"w");
}

void fichero::cerrarFichero ()
{
    fi.close();
}

void fichero::cerrarFicheroEscritura()
{
    fclose (pFile);
}

char * fichero::leerSiguienteLinea ()
{
    char text [250];
    char * retornado;

    fi.getline(text, 250);

    int temp = strlen (text);
    if (temp<10)
        temp=16;
    retornado = (char *) malloc (temp);
    strcpy (retornado, text);
    return retornado;
}

char * fichero::leerSiguienteLinea (int size)
{
    char text [100];
    char * retornado;

    fi.getline(text, 100);

    retornado = (char *) malloc (size);
    strcpy (retornado, text);
    return retornado;
}

void fichero::escribirLineaTexto (char * texto)
{
    if (pFile!=NULL)
    {
        strcat (texto, "\n");
        fputs (texto,pFile);
    }
}

void fichero::escribirLineaBoolean (char * texto, bool valor)
{
    if (pFile!=NULL)
    {
        if (valor)
        {
            strcat (texto, "T");
        }
        else
        {
            strcat (texto, "F");
        }
        escribirLineaTexto (texto);
    }
}

