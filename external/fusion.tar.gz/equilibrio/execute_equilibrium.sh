#g++ -o transporte *cpp
make
#rm *.cpp
#rm *.h
if [ ! $# -ne 1 ]; then
./equilibrium $1
fi
