/***************************************************************************
*   Copyright (C) 2008 by Antonio Gómez                                   *
*   antonio.gomez@ciemat.es                                               *
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <iostream>
using namespace std;

#include <climits>
#include <cstring>
#include <memory>

#include <stdlib.h>

#ifndef READERFLX_H
#include "readerflx.h"
#endif

#ifndef TIPOS_H
#include "tipos.h"
#endif

#ifndef TRANSPORT_H
#include "transport.h"
#endif

/**
    @author Antonio Gómez <antonio.gomez@ciemat.es>
    @file main_equilibrium.cpp
    @brief Clase principal del proyecto
    @version 0.02
    @date 18-05-2009
*/

int main(int argc, char *argv[])
{

    transport *t = new transport();
    readerFLX *read = new readerFLX();
    read->abrirFichero(argv[1]);
    read->leerFichero();
    read->cerrarFichero();
   
    t->setFicheroFLX(read->getContenidoFichero());
    t->calcularValoresTransporte();
    double valtransporte = t->calcularFuncionObjetivo();
	
    cout << "%f\n" << valtransporte;
    delete t;

    return EXIT_SUCCESS;
}
