/***************************************************************************
 *   Copyright (C) 2008 by Antonio Gómez                                   *
 *   antonio.gomez@ciemat.es                                               *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef READERFLX_H
#define READERFLX_H

#include <fstream>
#include <iostream>
#include <iomanip>

#ifndef FICHERO_H
#include "fichero.h"
#endif

#ifndef TIPOS_H
#include "tipos.h"
#endif

/**
    @author Antonio Gómez <antonio.gomez@ciemat.es>
    @file readerFLX.h
    @brief Esta clase lee el contenido de un fichero flx
    @version 0.01
    @date 30-01-2008
*/
class readerFLX : public fichero{
    private:
    //Variable que almacena el contenido de un fichero flx.
    strficheroFLX fich;
    //Cabecera del fichero flx.
    strCabecera cabecera;
    //Iteraciones del fichero.
    strIteracion iteraciones [300];

    /*Función que lee la cabecera de un fichero .flx
        Formato de la cabecera:
            nombre_fichero.flx
            betat= xxxx
            nhl= xxx
            chl= xxx
            rot= xxx
            rin= xxx
            rmd= xxx
            nrho=xxx    modnum=xxx
    */
    void leerCabecera ();

    /*Función que lee una iteración completa. Las iteraciones están formadas por:
            - Identificador de la iteración.
            - Una serie de líneas (con el mismo formato)
            - Resumen final de la iteración
            @return Estructura que almacena una iteración completa.
    */
    strIteracion leerIteracion ();

    /*Función que lee una línea individual de una iteración.
        Formato:
            m=xxx  n=xxx  rmn=xxx  zmn=xxx
            @return Devuelve una línea de una iteración del fichero flx.
    */
    strLinea leerLinea ();

    /*Función que lee el resumen de una iteración
        Formato:
            rho=xxx     1/q=xxx  vp=xxx
            b0=xxx      et=xxx   eh=xxx
            @return Devuelve el resumen de una iteración.
    */
    strResIteracion leerResumenIteracion();

    public:
    readerFLX();

    //Destructor: libera la memoria reservada para los elementos de la cabecera.
    ~readerFLX();

    //Función que obtiene todo el contenido de un fichero .flx
    void leerFichero ();
    /* Función que devuelve el contenido de un fichero en una estructura.
        @return Contenido del fichero en una estructura que representa al fichero.    
    */
    strficheroFLX getContenidoFichero ();
};

#endif
