/***************************************************************************
 *   Copyright (C) 2008 by Antonio Gómez                                   *
 *   antonio.gomez@ciemat.es                                               *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef TRANSPORT_H
#define TRANSPORT_H

#ifndef TIPOS_H
#include "tipos.h"
#endif

#include <iostream>
#include <math.h>
#include <stdlib.h>

/**
    @author Antonio Gómez <antonio.gomez@ciemat.es>
    @file transport.h
    @brief Esta clase analiza los datos que se leen de un fichero con formato flx. Puede, para cada m y n, calcular el valor que se desee (rmn o z
    @version 0.01
    @date 30-01-2008
 */
/*
    Esta clase analiza los datos que se leen de un fichero con formato flx.
    Puede, para cada m y n, calcular el valor que se desee (rmn o zmn).
*/
class transport {
private:
    //Estructura que almacena el contenido del fichero flx.
    strficheroFLX fich;
    //Estructura que almacena los resultados del procesamiento del fichero.
    strvaloresTransporte valTransport;


    /*Función que calcula el valor de Z para una determinada iteración.
        @param iter Iteración para la que calcular el valo.
        @param angle1 Primer ángulo para el que se calcula el valor.
        @param angle2 Segundo ángulo para el que se calcula el valor.
        @return Valor de la función para la iteración indicada.
    */
    double calcularFuncionZ (int iter, int ro, int fi);

    /*Función que calcula el valor de R para una determinada iteración.
        @param iter Iteración para la que calcular el valo.
        @param angle1 Primer ángulo para el que se calcula el valor.
        @param angle2 Segundo ángulo para el que se calcula el valor.
        @return Valor de la función para la iteración indicada.
    */
    double calcularFuncionR (int iter, int ro, int fi);

    /*Función que calcula el valor de B para una determinada iteración.
        @param iter Iteración para la que calcular el valo.
        @param angle1 Primer ángulo para el que se calcula el valor.
        @param angle2 Segundo ángulo para el que se calcula el valor.
        @return Valor de la función para la iteración indicada.
    */
    double calcularFuncionB (int iter, int ro, int fi);


    strvector3 calcularGradiente (int p, int ro, int fi);


    double modulo (strvector3 vector);

    strvector3 multiplicarVectores (strvector3 vector1, strvector3 vector2);
public:
    transport();

    ~transport();

    //Inicializa la estructura que almacena el contenido del fichero.
    void setFicheroFLX (strficheroFLX fichero);

    /*Función que devuelve la estructura calculada por la clase transport.
        @return Devuelve la estructura que calcula la clase.
    */
    strvaloresTransporte getValoresTransporte ();

    //Función que calcula la estructura.
    void calcularValoresTransporte ();
    
        /*Función que calcula el valor de la función objetivo a minimizar.
        @return valor de la función objetivo.
    */
    double calcularFuncionObjetivo ();
};

#endif
