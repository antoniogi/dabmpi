/***************************************************************************
 *   Copyright (C) 2008 by Antonio Gómez                                   *
 *   antonio.gomez@ciemat.es                                               *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef READERINPUT_H
#define READERINPUT_H

#include <cctype>

#ifndef FICHERO_H
#include "fichero.h"
#endif

#ifndef TIPOS_H
#include "tipos.h"
#endif

/**
    @author Antonio Gómez <antonio.gomez@ciemat.es>
    @file readerInput.h
    @version 0.01
    @date 30-01-2008
 */
class readerInput : public fichero
{
    private:
    int array_int [40];
    double array_double [40];
    bool array_bool [40];
    strdatos leerDatos();
    stroptimum leerOptimum ();
    strbootin leerBootin();
    strlinea leerLinea ();
    void leerArrayBool (char* text);
    void leerArrayDouble (char* text);
    void leerArrayDouble (char* text, bool leerIgual);
    void leerArrayInteger (char* text);
    strsigma_jstar leerArrayJStar (char * text);
    char * leerValor ();
    char * leerValor(char * text);
    char * leerValor(int size);

    public:
    readerInput();

    ~readerInput();

    strficheroInput leerFichero();
};

#endif
