/***************************************************************************
 *   Copyright (C) 2008 by Antonio Gómez                                   *
 *   antonio.gomez@ciemat.es                                               *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "readerflx.h"

readerFLX::readerFLX()
    :fichero()
{
}

//Libera la memoria reservada para los elementos de la cabecera.
readerFLX::~readerFLX()
{
    free (cabecera.nombreFichero);
    free (cabecera.betat);
    free (cabecera.chl);
    free (cabecera.rot);
    free (cabecera.rin);
    free (cabecera.rmd);
}

//Función que obtiene todo el contenido de un fichero .flx
void readerFLX::leerFichero ()
{
    leerCabecera();
    fich.cabecera = cabecera;
    for (int i = 0; i<cabecera.nrho; i++)
    {
        iteraciones[i] = leerIteracion();
        fich.iteraciones[i] = iteraciones[i];
        fich.numIteraciones = i;
    }
    fi.close();
}

/*Función que lee la cabecera de un fichero .flx
    Formato de la cabecera:
        nombre_fichero.flx
        betat= xxxx
        nhl= xxx
        chl= xxx
        rot= xxx
        rin= xxx
        rmd= xxx
        nrho=xxx    modnum=xxx
*/
void readerFLX::leerCabecera ()
{
    char text [50];
    char * eltosLinea [4];
    int i = 0;
    char *tok;

    //Obtención del nombre del fichero
    fi.getline(text, 50);
    cabecera.nombreFichero = (char*)malloc(strlen(text));
    strcpy (cabecera.nombreFichero, text);

    //Obtención del valor betat
    fi.getline (text, 50);
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    cabecera.betat = (char*)malloc(strlen(eltosLinea[1]));
    strcpy (cabecera.betat, eltosLinea[1]);

    //Obtención del valor nhl
    i=0;
    fi.getline (text, 20);
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    cabecera.nhl = atoi(eltosLinea[1]);

    //Obtención del valor chl
    i=0;
    fi.getline (text, 20);
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    cabecera.chl=(char*)malloc(strlen(eltosLinea[1]));
    strcpy (cabecera.chl, eltosLinea[1]);

    //Obtención del valor rot
    i=0;
    fi.getline (text, 50);
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    cabecera.rot=(char*)malloc(strlen(eltosLinea[1]));
    strcpy (cabecera.rot, eltosLinea[1]);

    //Obtención del valor rin
    i=0;
    fi.getline (text, 50);
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    cabecera.rin=(char*)malloc(strlen(eltosLinea[1]));
    strcpy (cabecera.rin, eltosLinea[1]);

    //Obtención del valor rmd
    i=0;
    fi.getline (text, 50);
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    cabecera.rmd=(char*)malloc(strlen(eltosLinea[1]));
    strcpy (cabecera.rmd, eltosLinea[1]);

    //Obtención de los valores nrho y modnum (están en una misma línea)
    i=0;
    fi.getline (text, 50);
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        if (i==1)
            tok=strtok (NULL, "modnum");
        else
            tok = strtok (NULL,"=");
    }
    cabecera.nrho = atoi(eltosLinea[1]);
    cabecera.modnum = atoi(eltosLinea[3]);
}

/*Función que lee una iteración completa. Las iteraciones están formadas por:
    - Identificador de la iteración.
    - Una serie de líneas (con el mismo formato) 
    - Resumen final de la iteración
*/
strIteracion readerFLX::leerIteracion ()
{
    char text [150];
    char * eltosLineaIteracion [2];
    char * eltosLinea [10];
    int i = 0;
    char *tok;
    int iteracion;
    bool continuar = true;
    strIteracion iter;

    //Obtención del identificador de la iteración.
    fi.getline (text, 150);
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLineaIteracion [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }
    iter.iter = atoi (eltosLineaIteracion[1]);

    //Lectura de las líneas que forman la interación. El número de líneas viene determinado por el valor modnum de la cabecera.
    for (int j = 0; (j<cabecera.modnum) && (continuar); j++)
    {
        iter.lineas[j] = leerLinea ();
        if (iter.lineas[j].fin==NULL)
        //if (iter.lineas[j].rmn==NULL)
            continuar = false;
        iter.numLineas = j;
    }

    //Obtención del resumen de la iteración.
    iter.resumen = leerResumenIteracion();

    return iter;
}

/*Función que lee una línea individual de una iteración.
    Formato:
        m=xxx  n=xxx  rmn=xxx  zmn=xxx
*/
strLinea readerFLX::leerLinea ()
{
    char text [150];
    char *eltosLineaIteracion [5];
    char * eltosLinea [3];
    int i = 0;
    int j = 0;
    char *tok;
    strLinea linea;

    //Obtención de la línea.
    j=0;
    fi.getline (text, 150);
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLineaIteracion[j] = (char *) malloc (strlen (tok));
        strcpy (eltosLineaIteracion[j], tok);
        j++;
        tok = strtok (NULL,"=");
    }

    //Obtención del valor m
    tok = strtok (eltosLineaIteracion [1], " ");
    linea.m = atoi(eltosLineaIteracion[1]);

    //Obtención del valor n
    i = 0;
    tok = strtok (eltosLineaIteracion [2], "rmn");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL, " ");
    }
    linea.n = atoi(eltosLineaIteracion[2]);

    //Obtención de los valores rmn y zmn
    i = 0;
    tok = strtok (eltosLineaIteracion [3], " ");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL, " ");
    }
    if (eltosLinea[0]!=NULL)
    {
        linea.rmndouble = atof (eltosLinea[0]);
    }

    if (eltosLineaIteracion[4]!=NULL)
    {
        linea.zmndouble = atof (eltosLineaIteracion[4]);
    }
    //strcpy (linea.rmn, eltosLinea[0]);
    strcpy (linea.fin, eltosLinea[0]);
    //strcpy (linea.zmn, eltosLineaIteracion [4]);

    //Se libera la memoria reservada.
    for (i=j-1; i>=0; i--)
    {
        free (eltosLineaIteracion[i]);
    }
    return linea;
}

/*Función que lee el resumen de una iteración
    Formato:
        rho=xxx     1/q=xxx  vp=xxx
        b0=xxx      et=xxx   eh=xxx
*/
strResIteracion readerFLX::leerResumenIteracion ()
{
    strResIteracion resIter;
    char text [150];
    char * eltosLineaIteracion [4];
    char * eltosLinea [10];
    int i = 0;
    char *tok;
    strLinea linea;

    //Estos valores están en dos líneas diferentes, así que primero se lee la primera línea
    i=0;
    fi.getline (text, 150);
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLineaIteracion [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }

    //Obtención del valor rho
    i = 0;
    tok = strtok (eltosLineaIteracion [1], "1/q");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL, "1/q");
    }
    strcpy(resIter.rho, eltosLinea [0]);

    //Obtención de los valores 1/q y vp
    i = 0;
    tok = strtok (eltosLineaIteracion [2], "vp");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL, "vp");
    }
    strcpy (resIter.q, eltosLinea [0]);
    strcpy (resIter.vp, eltosLineaIteracion[3]);

    //Lectura de la segunda línea
    i=0;
    fi.getline (text, 150);
    tok = strtok (text,"=");
    while (tok != NULL)
    {
        eltosLineaIteracion [i] = tok;
        i++;
        tok = strtok (NULL,"=");
    }

    //Obtención del valor b0
    i = 0;
    tok = strtok (eltosLineaIteracion [1], "et");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL, "et");
    }
    strcpy (resIter.b0, eltosLinea [0]);

    //Obtención de los valores et y eh
    i = 0;
    tok = strtok (eltosLineaIteracion [2], "eh");
    while (tok != NULL)
    {
        eltosLinea [i] = tok;
        i++;
        tok = strtok (NULL, "eh");
    }
    strcpy (resIter.et, eltosLinea [0]);
    strcpy (resIter.eh, eltosLineaIteracion[3]);

    return resIter;
}

//Función que devuelve el contenido de un fichero en una estructura.
strficheroFLX readerFLX::getContenidoFichero ()
{
    int x = fich.numIteraciones;
    return fich;
}



