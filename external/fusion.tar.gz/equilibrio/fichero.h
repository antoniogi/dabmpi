/***************************************************************************
*   Copyright (C) 2008 by Antonio Gómez                                   *
*   antonio.gomez@ciemat.es                                               *
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef FICHERO_H
#define FICHERO_H

#include <fstream>
#include <iostream>
#include <exception>
#include <cstring>
#include <stdlib.h>

/**
    @author Antonio Gómez <antonio.gomez@ciemat.es>
    @file fichero.h
    @brief Clase genérica de manejo de ficheros
    @version 0.01
    @date 30-01-2008
 */
class fichero{
    public:// private:
        std::fstream fi;
        FILE * pFile;
    public:
        fichero();

        ~fichero();

        void abrirFichero (char * nombre);

        void abrirFicheroEscritura (char * nombre);

        void cerrarFichero();

        void cerrarFicheroEscritura();

        char * leerSiguienteLinea ();

        char * leerSiguienteLinea (int size);

        void escribirLineaTexto (char * texto);

        void escribirLineaBoolean (char * texto, bool valor);

};

#endif
