chmod 777 xgrid
echo $1
./xgrid < $1
